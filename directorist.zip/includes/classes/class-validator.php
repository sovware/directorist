<?php
defined('ABSPATH') || die( 'Direct access is not allowed.' );
/**
 * @since 4.7.2
 * @package Directorist
 */
if(!class_exists('ATBDP_Validator')):

    class ATBDP_Validator{

        public function __construct()
        {


        }




    }

endif;

