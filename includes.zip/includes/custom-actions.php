<?php
/*This file will contain most common actions that will help other developer extends / modify our plugin settings or design */
function atbdp_after_new_listing_button()
{
    do_action('atbdp_after_new_listing_button');
}