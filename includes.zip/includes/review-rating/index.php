<?php
// protect folder from accessing directly
